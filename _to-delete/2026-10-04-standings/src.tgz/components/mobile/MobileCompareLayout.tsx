/**
 * Mobile Compare Layout
 * 
 * Main mobile layout wrapper for comparison interface
 * LAYOUT: theScore compact structure
 * STYLE: Neon Frame (Round 5 "R") — wordmark hero + framed Offense/Defense cards
 */

'use client';

import { memo, useMemo } from 'react';
import CompactPanel from './CompactPanel';
import MatchupHero from '@/components/compare/MatchupHero';
import { getMatchupPalettes } from '@/lib/teamColors';
import { DEFAULT_OFFENSE_METRICS, DEFAULT_DEFENSE_METRICS } from '@/lib/metricsConfig';
import type { TeamData } from '@/lib/useNflStats';

interface MobileCompareLayoutProps {
  selectedTeamA: string;
  selectedTeamB: string;
  onTeamAChange: (team: string) => void;
  onTeamBChange: (team: string) => void;
  offenseData: TeamData[];
  defenseData: TeamData[];
  selectedOffenseMetrics: string[];
  selectedDefenseMetrics: string[];
  onOffenseMetricsChange: (metrics: string[]) => void;
  onDefenseMetricsChange: (metrics: string[]) => void;
  isLoading?: boolean;
  /**
   * 'full' (default) = standalone viewport layout with top/bottom bars, used by
   * the Compare workspace. 'inline' = just the panels (no chrome, auto height)
   * for the Home accordion peek. Same compare UI either way — no duplication.
   */
  variant?: 'full' | 'inline' | 'quadrant';
}

function MobileCompareLayout({
  selectedTeamA,
  selectedTeamB,
  onTeamAChange,
  onTeamBChange,
  offenseData,
  defenseData,
  selectedOffenseMetrics,
  selectedDefenseMetrics,
  isLoading,
  variant = 'full',
}: MobileCompareLayoutProps) {
  
  // Use default 5 metrics if none selected
  const offenseMetrics = selectedOffenseMetrics.length > 0 
    ? selectedOffenseMetrics 
    : DEFAULT_OFFENSE_METRICS;
    
  const defenseMetrics = selectedDefenseMetrics.length > 0 
    ? selectedDefenseMetrics 
    : DEFAULT_DEFENSE_METRICS;
  
  // Find team data
  const teamAOffense = offenseData.find(t => t.team === selectedTeamA) || null;
  const teamBOffense = offenseData.find(t => t.team === selectedTeamB) || null;
  const teamADefense = defenseData.find(t => t.team === selectedTeamA) || null;
  const teamBDefense = defenseData.find(t => t.team === selectedTeamB) || null;

  // Overall W-L record lives on the defense (standings) rows. Read from the RAW
  // data (not per-game transformed) so "3-0" stays intact. Shown next to each
  // team's city in the wordmark hero.
  const teamARecord = typeof teamADefense?.record === 'string' ? teamADefense.record : null;
  const teamBRecord = typeof teamBDefense?.record === 'string' ? teamBDefense.record : null;

  // Team colors for the wordmarks (same resolution the panels use for bars/frames).
  const palettes = useMemo(() => getMatchupPalettes(selectedTeamA, selectedTeamB), [selectedTeamA, selectedTeamB]);

  // Quadrant uses a single uniform GAP (6px) as the dark-blue band everywhere:
  // left, top, bottom, between the two panels, and on each side of the control
  // box — so the stat panels fill most of the card and the leftover dark blue is
  // even on all sides. The remove (×) control is no longer a gutter box — it's an
  // edge tab rendered outside the card (see CompareQuadrants), so no extra right pad.
  // full/inline keep their original px-3/py-2 + BottomNav bottom reserve.
  const isQuad = variant === 'quadrant';
  const GAP = 6;
  // Phone: reserve just enough for the floating nav so Offense + Defense both fit
  // on one iPhone 14 Pro screen in app (standalone) mode.
  const padBottom = isQuad ? GAP : 'calc(var(--nav-h) + env(safe-area-inset-bottom) + 6px)';
  const padRight = isQuad ? GAP : undefined;
  const padLeft = isQuad ? GAP : undefined; // undefined → px-3 (12px) for full/inline
  const padTop = isQuad ? GAP : undefined;  // undefined → py-2 (8px) for full/inline
  const bodyClass = isQuad ? 'space-y-1.5' : 'px-3 pt-1 space-y-2'; // space-y-1.5 = 6px

  // Shared body: skeleton while loading, else the two compact panels.
  const body = isLoading ? (
    <div
      className={bodyClass}
      style={{ paddingBottom: padBottom, paddingRight: padRight, paddingLeft: padLeft, paddingTop: padTop }}
    >
      <PanelSkeleton rows={offenseMetrics.length || 5} />
      <PanelSkeleton rows={defenseMetrics.length || 8} />
    </div>
  ) : (
    <div
      className={bodyClass}
      style={{ paddingBottom: padBottom, paddingRight: padRight, paddingLeft: padLeft, paddingTop: padTop }}
    >
      {/* Team wordmarks (replace logos on Compare) — tap a name to change team */}
      <MatchupHero
        teamA={selectedTeamA}
        teamB={selectedTeamB}
        teamARecord={teamARecord}
        teamBRecord={teamBRecord}
        paletteA={palettes.a}
        paletteB={palettes.b}
        allTeams={offenseData}
        onTeamAChange={onTeamAChange}
        onTeamBChange={onTeamBChange}
        size={variant === 'full' ? 'lg' : 'sm'}
      />

      {/* Offense Panel */}
      <CompactPanel
        type="offense"
        teamA={selectedTeamA}
        teamB={selectedTeamB}
        teamAData={teamAOffense}
        teamBData={teamBOffense}
        teamARecord={teamARecord}
        teamBRecord={teamBRecord}
        selectedMetrics={offenseMetrics}
        allOffenseData={offenseData}
        allDefenseData={defenseData}
        onTeamAChange={onTeamAChange}
        onTeamBChange={onTeamBChange}
      />

      {/* Defense Panel */}
      <CompactPanel
        type="defense"
        teamA={selectedTeamA}
        teamB={selectedTeamB}
        teamAData={teamADefense}
        teamBData={teamBDefense}
        teamARecord={teamARecord}
        teamBRecord={teamBRecord}
        selectedMetrics={defenseMetrics}
        allOffenseData={offenseData}
        allDefenseData={defenseData}
        onTeamAChange={onTeamAChange}
        onTeamBChange={onTeamBChange}
      />
    </div>
  );

  // Inline (Home accordion peek) and quadrant (Compare 2×2): just the panels,
  // no chrome, natural height.
  if (variant === 'inline' || variant === 'quadrant') {
    return <div className="text-text" style={{ background: isQuad ? 'var(--bg-deep)' : 'var(--bg)' }}>{body}</div>;
  }

  return (
    /* Root: fills its container (the workspace pager cell) as a flex column.
       The shared title row + tabs pill live at the workspace level now, so this
       is just the scrollable cards area. height:100% (not 100dvh) so it slots
       under the workspace header/tab bar. */
    <div
      className="flex flex-col text-text"
      style={{ height: '100%', background: 'var(--bg-deep)' }}
    >
      {/* Scrollable Content — flex-1 fills remaining space. The persistent app
          BottomNav lives at the shell level now; the workspace root reserves its
          height so this content clears it.
          touch-action:pan-y lets the browser own vertical scroll; the pager's
          dragDirectionLock owns horizontal. overscroll:contain prevents any
          leftover scroll momentum from leaking to the document. */}
      <div
        className="flex-1 overflow-y-auto min-h-0"
        style={{ touchAction: 'pan-y', overscrollBehavior: 'contain' }}
      >
        {body}
      </div>
    </div>
  );
}

export default memo(MobileCompareLayout);

/** Skeleton mirroring a CompactPanel's header + rows to avoid layout shift. */
function PanelSkeleton({ rows }: { rows: number }) {
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
    >
      {/* Header */}
      <div className="h-[50px] px-3 grid grid-cols-[36px_1fr_36px] items-center gap-2">
        <div className="skeleton rounded-lg" style={{ width: 34, height: 34 }} />
        <div className="flex flex-col items-center gap-1">
          <div className="skeleton rounded-sm" style={{ width: 52, height: 9 }} />
          <div className="skeleton rounded-sm" style={{ width: 36, height: 8 }} />
        </div>
        <div className="skeleton justify-self-end rounded-lg" style={{ width: 34, height: 34 }} />
      </div>
      {/* Rows */}
      <div className="divide-y divide-white/5">
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="px-3 py-1">
            <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-1">
              <div className="skeleton rounded-sm" style={{ width: 44, height: 14 }} />
              <div className="skeleton mx-auto rounded-sm" style={{ width: 60, height: 8 }} />
              <div className="skeleton justify-self-end rounded-sm" style={{ width: 44, height: 14 }} />
            </div>
            <div className="skeleton mt-1 rounded-full" style={{ height: 6 }} />
          </div>
        ))}
      </div>
    </div>
  );
}

