/**
 * CompareQuadrants — the tablet/desktop Compare layout: a swipeable 2×2 grid.
 *
 * Shows up to four comparisons at once (each its own stacked Offense/Defense
 * compare pane). Empty quadrants show a "+" to add a comparison. You can still
 * swipe left/right — now paging between sets of four (the store caps at 8, so at
 * most two pages). Phones keep the single-pane swipe in CompareWorkspace; this
 * component is only mounted at tablet width and up.
 *
 * Each quadrant has its own remove (×) and its own metrics button, so the four
 * visible comparisons are edited independently.
 */

'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, useMotionValue, animate, type PanInfo } from 'framer-motion';
import { X } from 'lucide-react';
import { useComparisons, type Comparison, type ComparisonPatch } from '@/components/ComparisonsProvider';
import { APP_CONSTANTS } from '@/config/constants';
import { useFillComparison } from '@/lib/comparisons/useFillComparison';
import type { TeamData } from '@/lib/useNflStats';
import ComparePane from '@/components/compare/ComparePane';
import BlankComparePicker, { AddMark } from '@/components/compare/BlankComparePicker';

const PAGE = 4; // 2×2

interface Props {
  offenseData: TeamData[];
  defenseData: TeamData[];
  isLoading: boolean;
  isLoadingOffense: boolean;
  isLoadingDefense: boolean;
}

type Cell =
  | { kind: 'cmp'; id: string }
  | { kind: 'add' }
  | { kind: 'empty' };

export default function CompareQuadrants({
  offenseData,
  defenseData,
  isLoading,
  isLoadingOffense,
  isLoadingDefense,
}: Props) {
  const { comparisons, addComparison, removeComparison, updateComparison } = useComparisons();
  const fillComparison = useFillComparison();

  const canAdd = comparisons.length < APP_CONSTANTS.MAX_COMPARISONS;
  // One trailing slot's worth of "+" room when there's capacity to add.
  const pageCount = Math.max(1, Math.ceil((comparisons.length + (canAdd ? 1 : 0)) / PAGE));

  const [page, setPage] = useState(0);
  // Keep the active page in range when comparisons are added/removed.
  useEffect(() => {
    setPage((p) => Math.min(p, pageCount - 1));
  }, [pageCount]);

  // ── Pager measurement + x track ─────────────────────────────────────────────
  const viewportRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const x = useMotionValue(0);

  useEffect(() => {
    const measure = () => {
      if (viewportRef.current) setWidth(viewportRef.current.offsetWidth);
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  // Snap the track to the active page on page/width change (not mid-drag).
  useEffect(() => {
    const controls = animate(x, -page * width, { type: 'spring', stiffness: 320, damping: 34 });
    return controls.stop;
  }, [page, width, pageCount, x]);

  const handleDragEnd = useCallback(
    (_e: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
      const threshold = Math.max(60, width * 0.18);
      let target = page;
      if (info.offset.x < -threshold || info.velocity.x < -500) target = Math.min(page + 1, pageCount - 1);
      else if (info.offset.x > threshold || info.velocity.x > 500) target = Math.max(page - 1, 0);
      if (target !== page) setPage(target);
      else animate(x, -page * width, { type: 'spring', stiffness: 320, damping: 34 });
    },
    [page, width, pageCount, x],
  );

  const canDrag = pageCount > 1 && width > 0;

  const handleAdd = useCallback(() => {
    addComparison('', ''); // blank → BlankComparePicker in that quadrant
  }, [addComparison]);

  // Build the cells for one page.
  const cellsForPage = (p: number): Cell[] => {
    const out: Cell[] = [];
    for (let i = 0; i < PAGE; i++) {
      const idx = p * PAGE + i;
      if (idx < comparisons.length) out.push({ kind: 'cmp', id: comparisons[idx].id });
      else if (canAdd) out.push({ kind: 'add' });
      else out.push({ kind: 'empty' });
    }
    return out;
  };

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      {/* Pager viewport */}
      <div ref={viewportRef} className="relative flex-1 overflow-hidden">
        <motion.div
          className="flex h-full"
          style={{ x }}
          drag={canDrag ? 'x' : false}
          dragDirectionLock
          dragConstraints={{ left: -(pageCount - 1) * width, right: 0 }}
          dragElastic={0.12}
          onDragEnd={handleDragEnd}
        >
          {Array.from({ length: pageCount }).map((_, p) => {
            // Windowing: only mount the active page and its neighbors.
            const mounted = Math.abs(p - page) <= 1;
            return (
              <div
                key={p}
                className="h-full shrink-0 overflow-y-auto"
                style={{ width: width || '100%', touchAction: 'pan-y', overscrollBehavior: 'contain' }}
              >
                {mounted && (
                  <div
                    className="grid grid-cols-2 gap-3 p-3"
                    style={{ paddingBottom: 'calc(var(--nav-h) + env(safe-area-inset-bottom) + 16px)' }}
                  >
                    {cellsForPage(p).map((cell, i) => (
                      <Quadrant
                        key={cell.kind === 'cmp' ? cell.id : `${p}-${i}-${cell.kind}`}
                        cell={cell}
                        offenseData={offenseData}
                        defenseData={defenseData}
                        isLoading={isLoading}
                        isLoadingOffense={isLoadingOffense}
                        isLoadingDefense={isLoadingDefense}
                        // Any card can close; closing the last leaves a blank picker.
                        canRemove={
                          comparisons.length > 1 ||
                          Boolean(comparisons[0]?.teamA && comparisons[0]?.teamB)
                        }
                        onAdd={handleAdd}
                        onRemove={removeComparison}
                        onUpdate={updateComparison}
                        onFill={fillComparison}
                        comparison={
                          cell.kind === 'cmp'
                            ? comparisons.find((c) => c.id === cell.id)
                            : undefined
                        }
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </motion.div>
      </div>

      {/* Page dots (only when more than one page) */}
      {pageCount > 1 && (
        <div className="flex flex-none items-center justify-center gap-1.5 py-2">
          {Array.from({ length: pageCount }).map((_, p) => (
            <button
              key={p}
              type="button"
              aria-label={`Page ${p + 1}`}
              onClick={() => setPage(p)}
              className="rounded-full touch-optimized"
              style={{
                width: p === page ? 18 : 7,
                height: 7,
                background: p === page ? 'var(--gold)' : 'var(--border)',
                transition: 'width .2s, background .2s',
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ── One quadrant cell ─────────────────────────────────────────────────────────

interface QuadrantProps {
  cell: Cell;
  comparison?: Comparison;
  offenseData: TeamData[];
  defenseData: TeamData[];
  isLoading: boolean;
  isLoadingOffense: boolean;
  isLoadingDefense: boolean;
  canRemove: boolean;
  onAdd: () => void;
  onRemove: (id: string) => void;
  onUpdate: (id: string, patch: ComparisonPatch) => void;
  onFill: (id: string, teamA: string, teamB: string) => void;
}

function Quadrant({
  cell,
  comparison,
  offenseData,
  defenseData,
  isLoading,
  isLoadingOffense,
  isLoadingDefense,
  canRemove,
  onAdd,
  onRemove,
  onUpdate,
  onFill,
}: QuadrantProps) {
  const shell = 'rounded-xl overflow-hidden relative h-full';
  // Neon Frame: the quadrant shell is a quiet deep surface — the panels inside
  // carry the glowing frames, so no card-in-card double border.
  const shellStyle = { background: 'var(--bg-deep)', border: '1px solid var(--hairline)' } as const;

  // Empty "+" quadrant.
  if (cell.kind !== 'cmp' || !comparison) {
    if (cell.kind === 'empty') {
      return <div className={shell} style={{ ...shellStyle, minHeight: 160, opacity: 0.4 }} />;
    }
    return (
      <button
        type="button"
        onClick={onAdd}
        className={`${shell} flex min-h-[160px] flex-col items-center justify-center gap-3 touch-optimized active:opacity-70`}
        style={{ ...shellStyle, border: '1.5px dashed color-mix(in srgb, var(--gold-bright) 35%, transparent)' }}
        aria-label="Add comparison"
      >
        <AddMark size={44} />
        <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: '0.22em', color: 'var(--subtext)' }}>ADD COMPARISON</span>
      </button>
    );
  }

  const c = comparison;
  const hasTeams = Boolean(c.teamA && c.teamB);

  return (
    <div className="relative h-full">
      <div className={shell} style={shellStyle}>
        {hasTeams ? (
          <ComparePane
            isMobile
            inline
            quadrant
            teamA={c.teamA}
            teamB={c.teamB}
            offenseData={offenseData}
            defenseData={defenseData}
            selectedOffenseMetrics={c.settings.offenseMetrics}
            selectedDefenseMetrics={c.settings.defenseMetrics}
            isLoading={isLoading}
            isLoadingOffense={isLoadingOffense}
            isLoadingDefense={isLoadingDefense}
            onTeamAChange={(t) => onUpdate(c.id, { teamA: t })}
            onTeamBChange={(t) => onUpdate(c.id, { teamB: t })}
            onOffenseMetricsChange={(m) => onUpdate(c.id, { settings: { offenseMetrics: m } })}
            onDefenseMetricsChange={(m) => onUpdate(c.id, { settings: { defenseMetrics: m } })}
          />
        ) : (
          <div className="p-3">
            <BlankComparePicker
              teamA={c.teamA}
              teamB={c.teamB}
              offenseData={offenseData}
              onTeamAChange={(t) => onUpdate(c.id, { teamA: t })}
              onTeamBChange={(t) => onUpdate(c.id, { teamB: t })}
              onPickMatchup={(a, b) => onFill(c.id, a, b)}
            />
          </div>
        )}
      </div>

      {/* Close control: a small tab fused to the card's RIGHT EDGE (bookmark
          style). Rendered OUTSIDE the overflow-hidden card so it can jut out a
          few px. Metrics editing was removed from the quadrant view — each
          comparison shows its default metric set (⚙ button retired). */}
      {canRemove && (
        <button
          type="button"
          onClick={() => onRemove(c.id)}
          aria-label="Remove comparison"
          className="absolute z-10 flex items-center justify-center touch-optimized active:opacity-60"
          style={{
            top: 14,
            right: -10, // protrude ~10px past the card edge (sits in the grid gap/padding — no page overflow)
            width: 22,
            height: 30,
            color: 'color-mix(in srgb, var(--gold-bright) 65%, transparent)', // soft gold ×
            background: 'var(--bg-deep)',
            // Longhands only (no `border` + `borderLeft` mix → React re-render warning).
            borderStyle: 'solid',
            borderColor: 'var(--hairline)',
            borderWidth: '1px 1px 1px 0', // no left edge: flush against the card's right edge
            borderRadius: '0 9px 9px 0', // round only the outer (right) corners → reads as a tab
            boxShadow: '2px 0 6px -2px rgba(0,0,0,0.45)',
          }}
        >
          <X size={14} />
        </button>
      )}
    </div>
  );
}
