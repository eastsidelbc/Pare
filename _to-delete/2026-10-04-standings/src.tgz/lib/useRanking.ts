/**
 * Client-side ranking system for NFL metrics
 * 
 * This hook provides real-time ranking calculations for any metric,
 * with proper tie handling and league-wide context.
 * 
 * Completely independent of API ranking logic - uses raw data only.
 */

'use client';

import { useMemo } from 'react';
import { TeamData } from './useNflStats';
import { formatRank } from '@/utils/ordinal';

/** Dev-only diagnostic logging (stripped from production hot paths). */
const RANKING_DEBUG = process.env.NODE_ENV !== 'production';

/**
 * Compare two numeric values with floating-point tolerance
 * 
 * @param a - First value
 * @param b - Second value
 * @param epsilon - Tolerance (default: 0.001 for 3 decimal places)
 * @returns true if values are equal within tolerance
 * 
 * @example
 * areValuesEqual(5.7, 5.700001)  // true
 * areValuesEqual(5.7, 5.8)       // false
 */
function areValuesEqual(a: number, b: number, epsilon = 0.001): boolean {
  return Math.abs(a - b) < epsilon;
}

export interface RankingResult {
  rank: number;
  formattedRank: string; // "T-12th", "1st", etc.
  isTied: boolean;
  totalTeams: number;
  teamsWithSameValue: number;
}

export interface RankingOptions {
  higherIsBetter?: boolean; // true for offense stats, false for defense stats
  excludeSpecialTeams?: boolean; // exclude "Avg Team", "League Total", etc.
}

/**
 * Calculate rankings for a specific metric across all NFL teams
 */
export function useRanking(
  allData: TeamData[], 
  metricKey: string, 
  targetTeamName: string,
  options: RankingOptions = {}
): RankingResult | null {
  // Destructure primitives up front so the memo below depends on stable values.
  // Callers pass a fresh `options` object literal each render — depending on the
  // object directly would defeat memoization and recompute ranking every render.
  const { higherIsBetter = true, excludeSpecialTeams = true } = options;

  return useMemo(() => {
    // 🔒 TYPE SAFETY: Improved error handling with logging
    if (!allData || allData.length === 0) {
      if (RANKING_DEBUG) console.warn(`[useRanking] No data provided for ranking calculation (metric: ${metricKey})`);
      return null;
    }
    
    if (!metricKey) {
      if (RANKING_DEBUG) console.warn(`[useRanking] No metric key provided for ranking calculation`);
      return null;
    }
    
    if (!targetTeamName) {
      if (RANKING_DEBUG) console.warn(`[useRanking] No target team name provided for ranking calculation (metric: ${metricKey})`);
      return null;
    }

    if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Computing rank for ${targetTeamName} - ${metricKey}`);

    // Filter out special teams if requested
    let filteredData = allData;
    if (excludeSpecialTeams) {
      filteredData = allData.filter(team => 
        !['Avg Team', 'League Total', 'Avg Tm/G', 'Avg/TmG'].includes(team.team)
      );
    }

    if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Filtered data: ${filteredData.length} teams`);

    // Get the target team's value
    const targetTeam = filteredData.find(team => team.team === targetTeamName);
    if (!targetTeam) {
      if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Target team not found: ${targetTeamName}`);
      return null;
    }

    // Get numeric value for the metric
    const targetValue = parseFloat(String(targetTeam[metricKey] || '0'));
    if (isNaN(targetValue)) {
      if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Invalid metric value for ${targetTeamName}: ${targetTeam[metricKey]}`);
      return null;
    }

    if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Target value: ${targetValue}`);

    // Count teams with better values
    let betterTeamsCount = 0;
    let teamsWithSameValue = 0;

    filteredData.forEach(team => {
      const teamValue = parseFloat(String(team[metricKey] || '0'));
      if (isNaN(teamValue)) return;

      if (areValuesEqual(teamValue, targetValue)) {
        teamsWithSameValue++;
      } else if (higherIsBetter && teamValue > targetValue) {
        betterTeamsCount++;
      } else if (!higherIsBetter && teamValue < targetValue) {
        betterTeamsCount++;
      }
    });

    // Calculate rank: number of better teams + 1
    const rank = betterTeamsCount + 1;
    const isTied = teamsWithSameValue > 1;

    if (RANKING_DEBUG) console.log(`🏆 [USE-RANKING] Results:`, {
      betterTeamsCount,
      rank,
      isTied,
      teamsWithSameValue,
      higherIsBetter
    });

    const formattedRank = formatRank(rank, isTied);

    return {
      rank,
      formattedRank,
      isTied,
      totalTeams: filteredData.length,
      teamsWithSameValue
    };

  }, [allData, metricKey, targetTeamName, higherIsBetter, excludeSpecialTeams]);
}

/**
 * Bulk ranking function for getting ranks of multiple teams at once
 * Note: This is a utility function, not a hook
 */
export function calculateBulkRanking(
  allData: TeamData[],
  metricKey: string,
  teamNames: string[],
  options: RankingOptions = {}
): Record<string, RankingResult | null> {
  const results: Record<string, RankingResult | null> = {};
  
  if (!allData || allData.length === 0 || !metricKey) {
    return results;
  }

  const { higherIsBetter = true, excludeSpecialTeams = true } = options;
  
  let filteredData = allData;
  if (excludeSpecialTeams) {
    filteredData = allData.filter(team => 
      !['Avg Team', 'League Total', 'Avg Tm/G', 'Avg/TmG'].includes(team.team)
    );
  }

  teamNames.forEach(teamName => {
    const targetTeam = filteredData.find(team => team.team === teamName);
    if (!targetTeam) {
      results[teamName] = null;
      return;
    }

    const targetValue = parseFloat(String(targetTeam[metricKey] || '0'));
    if (isNaN(targetValue)) {
      results[teamName] = null;
      return;
    }

    let betterTeamsCount = 0;
    let teamsWithSameValue = 0;

    filteredData.forEach(team => {
      const teamValue = parseFloat(String(team[metricKey] || '0'));
      if (isNaN(teamValue)) return;

      if (areValuesEqual(teamValue, targetValue)) {
        teamsWithSameValue++;
      } else if (higherIsBetter && teamValue > targetValue) {
        betterTeamsCount++;
      } else if (!higherIsBetter && teamValue < targetValue) {
        betterTeamsCount++;
      }
    });

    const rank = betterTeamsCount + 1;
    const isTied = teamsWithSameValue > 1;

    results[teamName] = {
      rank,
      formattedRank: formatRank(rank, isTied),
      isTied,
      totalTeams: filteredData.length,
      teamsWithSameValue
    };
  });
  
  return results;
}

/**
 * Get league-wide ranking statistics for a metric
 */
export function useMetricStats(
  allData: TeamData[],
  metricKey: string,
  options: RankingOptions = {}
): {
  min: number;
  max: number;
  average: number;
  median: number;
  totalTeams: number;
} | null {
  
  return useMemo(() => {
    if (!allData || allData.length === 0 || !metricKey) {
      return null;
    }

    const { excludeSpecialTeams = true } = options;
    
    let filteredData = allData;
    if (excludeSpecialTeams) {
      filteredData = allData.filter(team => 
        !['Avg Team', 'League Total', 'Avg Tm/G', 'Avg/TmG'].includes(team.team)
      );
    }

    const values = filteredData
      .map(team => parseFloat(String(team[metricKey] || '0')))
      .filter(val => !isNaN(val))
      .sort((a, b) => a - b);

    if (values.length === 0) return null;

    const min = values[0];
    const max = values[values.length - 1];
    const average = values.reduce((sum, val) => sum + val, 0) / values.length;
    const median = values.length % 2 === 0 
      ? (values[values.length / 2 - 1] + values[values.length / 2]) / 2
      : values[Math.floor(values.length / 2)];

    return {
      min,
      max,
      average: Math.round(average * 100) / 100,
      median: Math.round(median * 100) / 100,
      totalTeams: values.length
    };

  }, [allData, metricKey, options]);
}
