# Pare Design System

> Living source of truth for how Pare looks. Dark-mode only, mobile-first.
> Supersedes `styleguide.md` (which drifted — see §7). Last codified: 2026-10-01.

---

## 0. The one principle: make the right thing the easy thing

The tokens already exist in `app/globals.css`. The problem isn't the tokens — it's that
nothing *forces* components to use them, so half of them hardcode the values instead.
Every rule below exists to make using a token easier than not using one. Think of it like
a kitchen: the tokens are labeled jars on one shelf; right now people keep buying duplicate
spices because the shelf isn't at arm's reach. We're moving the shelf to arm's reach.

**`app/globals.css` `:root` is the ONLY place a color/radius/shadow value is allowed to be
written as a literal.** Everywhere else references it. If you're typing a `#hex`, an
`rgba(...)`, or a `slate-900` in a component, that's a bug.

---

## 1. Tokens (names + meaning — values live in globals.css)

**Surfaces — an elevation ladder, low → high:**
`--bg` (page) → `--surface` (a raised region) → `--card` (a thing sitting on a surface).
Rule: **a container is exactly ONE rung above its children — never the same rung.** A `--card`
inside a `--card` is the bug you spotted in the quadrant ("too many lines"): two identical
surfaces separated only by a border that carries no information. Like framing a photo, then
putting that frame inside an identical frame.

**Border:** `--border`. Used **only where elevation or a gap can't separate two things.**
Prefer a gap. Two cards side by side? Space between them, no borders facing each other.

**Accents:** `--gold` is THE primary accent (active, rankings, emphasis). `--gold-bright` is
for high-emphasis only (a filled #1 badge). Pick one per context and stick to it — today the
app mixes both as the "active tint" and they're different colors.
Team bars: Team A = `--green`, Team B = `--fire`. Never `green-500`/`#22c55e`/`orange-500`.
Status: `--red` (live/loss), `--blue` (info), `--green` (win).

**Text:** `--text` (primary) → `--subtext` (secondary) → `--muted` (tertiary/disabled).
`text-white` is NOT `--text` (#f1f5f9) — stop using `text-white` for body text.

**Radius scale:** `--radius-sm` 6 (chips) · `--radius-md` 10 (buttons/badges) ·
`--radius-lg` 14 (cards) · `--radius-xl` 20 (sheets/floating panels). **There is no 12px.**
Tailwind's `rounded-xl` is 12px — do not use it for cards; cards are `--radius-lg` (14).

**Shadows:** `--shadow-card` (resting cards) · `--shadow-pop` (floating/overlays). No ad-hoc
`shadow-2xl shadow-black/50`.

**Spacing:** stay on a 2/4/6/8/10/12 rhythm. Don't mix Tailwind half-steps (`py-1.5`) with
raw inline `marginLeft: 6` in the same component.

---

## 2. Current drift (2026-10-01 audit — representative sample of 8 components)

Ranked by how pervasive. Fix order mirrors this.

1. **Token values hardcoded as literals** (most pervasive — 6/8 files). Examples:
   - `CompactComparisonRow.tsx`: bar gradients `#16a34a→#22c55e` (= `--green`) and
     `#ff6b35→#ea580c` (= `--fire`) written as literals.
   - `BottomNav.tsx` + `DivisionTable.tsx`: `rgba(245,200,66,…)` (= `--gold-bright`) as the
     active tint; `LeaderCard.tsx`: `rgba(212,168,67,…)` (= `--gold`). **Two different golds**
     doing the same job across files.
2. **Raw Tailwind palette as surfaces/text/borders.** Worst offender: **`TeamDropdown.tsx`** —
   styled entirely in `bg-slate-900/95`, `border-slate-700/50`, `text-slate-300/500`,
   `bg-green-500/20`, `border-l-orange-400`, with **zero tokens**. (`green-500` IS `--green`;
   `orange-500` ≈ `--fire`.) Also `text-white` for stat values in `CompactComparisonRow.tsx`;
   `divide-white/5` / `bg-white/5` for dividers/tracks instead of `--border`.
3. **Off-ladder surfaces + ad-hoc shadows.** `TeamDropdown.tsx` `bg-slate-900/95` (#0f172a —
   not on the ladder) with `shadow-2xl shadow-black/50` instead of `--shadow-pop`.
4. **Radius inconsistency.** Cards disagree: `CompactPanel.tsx`, `DivisionTable.tsx`,
   `LeaderCard.tsx` use `rounded-xl` (12px); only `MatchupCard.tsx` uses `var(--radius-lg)`
   (14px). `TeamDropdown.tsx` uses `rounded-lg` (8px — off scale entirely).
5. **Accent inconsistency.** Two golds (above); team accents as palette classes in
   `TeamDropdown.tsx`; stale doc-comments in `CompactPanel`/`CompactComparisonRow` claim
   "purple accents" that don't exist in the code.
6. **Spacing micro-drift.** `LeaderCard.tsx` mixes `py-1.5`/`pl-1.5` with inline
   `marginRight: 2` / `marginLeft: 6`.

**Already clean — copy these:** `MatchupCard.tsx` (exemplary — tokens for every
color/radius/shadow), `BottomNav.tsx` (one stray gold literal), `DivisionTable.tsx` (one stray
gold literal), `CardGrid.tsx` (pure layout, no color).

**Aside:** `@react-spring/web` is a dependency but no sampled component imports it (all use
`framer-motion`). Verify repo-wide; if truly unused, drop it — one animation library.

---

## 3. The highest-leverage fix: put the tokens IN Tailwind

Right now `tailwind.config.js` only maps `background`/`foreground`. Map the whole token set,
and the correct classes become the *easy* ones (`bg-card`, `text-subtext`, `border-border`,
`rounded-lg` = 14). Drift stops being convenient.

```js
// tailwind.config.js → theme.extend
colors: {
  bg: 'var(--bg)',
  surface: 'var(--surface)',
  card: 'var(--card)',
  border: 'var(--border)',
  gold: 'var(--gold)',
  'gold-bright': 'var(--gold-bright)',
  green: 'var(--green)',
  fire: 'var(--fire)',
  red: 'var(--red)',
  blue: 'var(--blue)',
  text: 'var(--text)',
  subtext: 'var(--subtext)',
  muted: 'var(--muted)',
},
borderRadius: {
  sm: 'var(--radius-sm)',  // 6
  md: 'var(--radius-md)',  // 10
  lg: 'var(--radius-lg)',  // 14  ← note: Tailwind's default lg is 8; this re-maps it on purpose
  xl: 'var(--radius-xl)',  // 20  ← and xl was 12; now 20
},
boxShadow: {
  card: 'var(--shadow-card)',
  pop:  'var(--shadow-pop)',
},
```

Micro-learning / the catch: re-mapping `borderRadius.lg`/`xl` changes what existing
`rounded-lg`/`rounded-xl` classes render. That's intentional (it drags everything onto the
scale) but it IS a visual shift — do it as one commit and eyeball the screens. After this,
`rounded-xl` cards become 20px; you likely want `rounded-lg` (14) for cards instead.

---

## 4. Component recipes (the canonical patterns)

- **Card** (a thing on a surface): `bg-card border border-border rounded-lg shadow-card`.
  One border max. If it holds sub-cards, the parent drops to `bg-surface` (or transparent) so
  the children are the only `--card`s.
- **Panel group in a frame** (the quadrant lesson): the frame is `bg-transparent` or
  `bg-surface` with **no border**; the panels inside are the `--card`s; separate them with a
  `gap`, not borders. Controls that "attach" to a frame need a visible frame edge — if the
  frame is transparent, a close affordance becomes a floating corner button, not a tab.
- **Pill / badge:** `rounded-md`, `--gold`/`--gold-bright` tint for active, `--muted` for rest.
- **Button:** `rounded-md`; primary = gold, ghost = `--muted` text on transparent.
- **Dropdown / popover / dialog / tabs / tooltip:** don't hand-roll (click-outside, focus,
  escape, aria). Use Radix primitives (§6) themed with tokens.

---

## 5. Migration order (when you say go — surgical, screen by screen)

1. **Wire tokens into Tailwind (§3)** — the foundation; everything else gets easier after.
2. **`TeamDropdown.tsx`** — biggest offender; rebuild on Radix + tokens (kills the most drift
   in one file).
3. **Literals → `var(--…)`**: `CompactComparisonRow` bar gradients → `--green`/`--fire`;
   the gold tints in `BottomNav`/`DivisionTable`/`LeaderCard` → one gold token.
4. **Radius pass**: cards → `rounded-lg` (14) everywhere; retire `rounded-xl` on cards.
5. **`text-white` → `text-text`**, `divide-white/5` → `divide-border`.
6. **Reconcile `styleguide.md`** (§7) or delete it in favor of this doc.

---

## 6. Tooling & libraries (recommended, stack-aware)

You already run Tailwind v3 + Radix (`react-dropdown-menu`, `react-select`) + framer-motion +
lucide. Build ON that, don't replace it.

- **`class-variance-authority` (CVA) + `tailwind-merge` + `clsx`** — the core trio for a
  Tailwind design system. CVA = a recipe card: define a `<Surface>` / `<Button>` once with
  its `variant`/`size`/`elevation` options, and every instance is guaranteed consistent and
  typed. `tailwind-merge` stops conflicting classes from fighting; `clsx` composes them.
  *This is the thing that makes "codify" real in code.* (Alt: `tailwind-variants` — same idea,
  nicer slot API; pick one.)
- **shadcn/ui** — not a dependency; a library of accessible components you **copy into the
  repo** (built on Radix + Tailwind + CVA) and own. Perfect for a vibe coder: you get a
  correct `Dialog`/`DropdownMenu`/`Tabs`/`Tooltip`/`Button`, then re-skin with your tokens.
  Use it as the component layer — especially to replace the hand-rolled `TeamDropdown` /
  `RankingDropdown`.
- **Radix primitives** — standardize ALL interactive bits on Radix (add `@radix-ui/react-dialog`,
  `-popover`, `-tabs`, `-tooltip` as needed). You get keyboard nav, focus trapping, and ARIA
  for free — the stuff hand-rolled dropdowns get wrong.
- **Enforcement (cheap, token-thrifty):** a CI grep that fails on raw palette classes / hex in
  `components/` + `app/` (e.g. ripgrep for `(bg|text|border)-(slate|gray|zinc|green|orange|purple)-` and `#[0-9a-fA-F]{6}`). Or `eslint-plugin-tailwindcss` for class hygiene. Keeps drift
  from creeping back after you clean it.

**Skip for now (overkill for a solo hobby project):** Style Dictionary (token build pipeline —
your `globals.css` + Tailwind map is enough), Storybook (heavy to maintain solo). If you want
a visual reference, add a single `/design` route in the app that renders swatches + every
component state — zero new deps, and it doubles as a QA page.

---

## 7. Fix the system's own bugs first (`styleguide.md` drift)

`styleguide.md` is the ancestor of this drift and must be reconciled or retired:
- It defines `--gold: #f5c842` — but `globals.css` says `--gold` is `#d4a843` and `#f5c842` is
  `--gold-bright`. Components copied the wrong gold. **Decide which gold is "primary" and make
  one authoritative.**
- It specs card `border-radius: 12px` — the token scale has no 12; cards should be 14
  (`--radius-lg`).

Recommendation: let **this file** be the source of truth, update `globals.css` usage to match,
and replace `styleguide.md` with a one-line pointer here (or stage it to `_to-delete/`).

---

## 8. Neon Frame — the Compare look (Round 5 "R", 2026-10-02)

The approved redesign direction. Live on **Compare only** for now; written as a template so
it can be promoted app-wide later (swap `--bg` → `--bg-deep`, `--card` → deep card gradient).
Mockups: the "Pare Compare Redesign" canvas (rounds 1–5; R = the pick, nav = Round 4 K).

**Surface ladder (tokens — change the look in `globals.css`, never in components):**
`--nav-bg` (darkest, so the nav separates) < `--bg-deep` page (#0a0d14 deep navy-slate) <
`--card-deep-*` cards (one step lighter, so they read as objects). Chosen as option "C" in the
Background ladder study (2026-10-03) over near-black #030409: easier on the eyes, no OLED
black-smear when scrolling, nav no longer melts into the page; glows lose only a little punch.
Team-color contrast is computed against this background (`COMPARE_BG` in `lib/teamColors.ts`).

**Surfaces:** page `--bg-deep`. Cards = 2px frame whose border fades
team A color → `--frame-mid` → team B color, with each team's glow (34px, 34%) spilling off its side;
inside, a `--card-deep-a → --card-deep-mid → --card-deep-b` gradient. Row dividers `--hairline`.

**Team colors (not tokens — brand data):** `lib/teamColors.ts`. Rules: (1) lift dark colors to
≥3:1 on `--bg-deep`; (2) clash → right side swaps to its alt, then left, then both;
(3) fallback to `--green` / `--fire`. Every 32×32 matchup is unit-tested to stay distinct.

**Team identity = wordmarks, not logos** (licensing): city + record small caps, nickname in
Inter 900 outlined (`-webkit-text-stroke`) in the team's line color with a soft glow.
Component: `components/compare/MatchupHero.tsx`.

**The split-capsule bar** (`components/ui/SplitCapsuleBar.tsx`): two see-through neon tubes
meeting at the exact `useBarCalculation` ratio, a short flush white divider, leader glows
brighter. Numbers are all white (`--text`) — the trailing team is never greyed out.

**Rank tiers** (`lib/rankTier.ts`, one definition):

| Rank | Bar | Badge |
|---|---|---|
| #1 | gold ring + gold sparks + fast team-color breathe | filled gold |
| #2–5 | soft team-color breathe only (gold is #1's alone) | gold tint |
| #6–27 | plain | slate |
| #28–31 | plain | red outline (static) |
| #32 | plain | solid red "ember" glow (`effects` prop) |

**Motion budget:** widths spring via framer-motion; glows are opacity-only CSS keyframes
(`pare-*` in globals.css); blur layers only on top-5 sides; everything stops under
`prefers-reduced-motion`. Effects are opt-in on `RankBadge` so Standings stay static.
**Play on change, then settle** (perf Pass 2, 2026-10-03): every tier effect runs a short, finite
burst when it mounts — first load, team swap, PG/TOT (`SplitCapsuleBar` `effectKey`, `RankBadge`
keyed by team) — then holds a still state. The aura stays invisible while the bar slides (0.5s
delay) so its blur isn't redrawn every spring frame. Nothing on Compare loops forever.
**GPU layers (perf Pass 4, from the iPhone Web Inspector recording):** every animated effect
class carries `will-change` (aura/ember → opacity, sparks → transform + opacity) so a fading glow
redraws only itself — un-layered, Safari repainted the whole card area ~7×/s for the whole effect
window. The #32 ember pulses an `::after` layer's opacity (box-shadow never animates). The
bar meeting-point divider is static (opacity 0.9).
Comparison tab pills: every pill is washed in its two teams' colors — 22% active, 14% inactive.

**Nav (Round 4 K):** `--nav-bg` capsule (darkest surface; no backdrop blur — at 94% opacity it was
invisible, pixel diff max 2/255, but cost a re-blur per frame); the active tab is a sliding gold neon outline
(`--gold-bright` border + glow). Sizing unchanged (`--nav-pill-h`).

**Density rule:** on an iPhone 14 Pro in app mode (393×759 usable) Offense **and** Defense
(5 + 5 default metrics) fit without scrolling. Re-check with any change to row/hero height.

**Menus & pickers (`components/ui/neonMenu.ts`):** team picker and rank list share one look —
deep gradient card, `--frame-mid` edge, `--hairline` rows, gold-bright small-caps header,
dimmed deep backdrop (plain dim, **no backdrop-filter blur** — a full-screen blur over animating
cards re-blurs every frame on iPhone). Rows are **40px** (`MENU_ROW_H`), fading up with a
CSS stagger (`.pare-row-in`). Height follows the screen: Floating UI
`size()` with `MENU_VIEWPORT_PADDING` (bottom keeps clear of the nav) — ~12–16 rows on a
14 Pro, ~24–26 on an iPad. Current row = 2px gold-bright edge + 8% gold tint.

**TeamMark (`components/ui/TeamMark.tsx`):** 2–3 letter abbreviation in the wordmark voice
(Inter 900, team-color outline + glow, fixed width so lists align). Replaces logo artwork in
lists/pickers. Unknown teams (League Average) → muted. Color = `getTeamPalette()` (lifted, no
clash logic — single team).

**Empty / add states:** dashed gold-bright outline + `AddMark` (gold neon "+" ring) for the
blank-comparison slots (no text — the "+" says it) and the tablet "Add comparison" cell; a filled
slot wears the team-color frame + TeamMark + nickname wordmark. "VS" = small gold italic 900.
Below the slots, `WeekMatchupPills`: this week's games as pills (`AWAY vs HOME` in plain
white 13px/700 text, two-team-color wash like the tab pills; second line = kickoff "Sun 1:00 PM",
live clock in red, or "Final"; 44px tall) — one tap fills both teams.

**Type roles (one family — Inter — styled by role):** *Display* (team wordmarks) = outlined 900,
**20px and up only** — outlines thinner than the letter counters are hard to read at small sizes.
*Controls* (nav, pills, buttons, list names) = solid 600–700, ~12–14px. *Labels* ("POINTS",
"OFFENSE", "WEEK 5") = small uppercase, tracked, subtext/gold. *Numbers* = solid 800, tabular.

**Power Surge (`components/ui/StormCrackle.tsx`, rules in `lib/powerSurge.ts`):** a team ranked
**top 5 in ≥ 3 of a card's metrics** gets a storm-crackle effect on its half of that card
(Offense and Defense judged separately; ranks = the row badges, same per-game/total data).
Chosen option "B·9": faint plasma web always on + edge arcs flaring at random (0.5–1.1 s on,
1.5–3.5 s off), Subtle intensity, team color, CSS mask fading to the middle. One canvas per
powered half, 30 fps, paused off-screen/hidden tab; reduced motion → still glow. Plays for
4 s when it mounts (card appears / team swap), fades, then leaves the still glow and stops its
frame loop (perf Pass 2).

## 9. Global rules — Neon Frame app-wide (written 2026-10-03, Compare finished)

Compare is the reference screen. Every other tab (Home, Standings, Leaders, and anything new)
follows these rules. Where a pattern isn't decided yet it says **TBD (mockup first)** — those get
designed with side-by-side mockups before code, then written here.

**1. Surfaces (one ladder, tokens only).** Nav `--nav-bg` (darkest) < page `--bg-deep` < cards
`--card-deep-*` gradient < raised/pressed states. Components never hardcode a surface color.
Migration: a tab switches its page from `--bg` → `--bg-deep` and its cards from `--card` →
the deep card recipe (§8). The old `--bg` (#0a0e1a) is already within a hair of `--bg-deep`, so
the page change is low-risk; the visible change is the cards. When every tab is migrated, the
old `--bg / --surface / --card` values get pointed at the deep tokens and retired.

**2. Type roles (one family: Inter).**
- *Display* — team wordmarks / big names: outlined 900, **20px and up only**.
- *Controls* — nav, buttons, pills, list names: solid 600–700, ~12–14px, white (gold when active).
- *Labels* — section/stat labels: ~9–11px, uppercase, tracked .14–.26em, `--subtext` (gold for a
  section header that acts as a title).
- *Numbers* — solid 800, `tabular-nums`, white. Never grey-out a "losing" stat (Compare). Exception:
  a **final game score** — the loser dims to `--muted` (§9.1), like every scoreboard.

**3. Accent.** `--gold-bright` = interactive/UI accent only (active nav, active toggle, "+", ×,
headers like "WEEK 5", current-row marker). Team colors = identity only (never for UI state).
Red = live / bad rank. Don't introduce new accent colors.

**4. Team identity — no logo artwork anywhere.** Big context → nickname wordmark (§8 Hero).
Small context → plain abbreviation (white text) or `TeamMark` at sizes where its outline is
readable; team color carried by a wash, frame, or the mark — not by tinting body text.

**5. Where team color + glow is allowed.** Single-matchup cards (Compare cards, a game card that
pairs two teams): team-color frame + side glows. **Busy lists/tables (32 teams): color on the
team mark only, rows stay neutral** — no frames or glows per row.

**6. Card types.**
- *Matchup card* (two teams): Neon Frame recipe (§8). Home game cards = **"Frame Row"** (§9.1 below).
- *List / table card* (Standings divisions, Leaders lists): deep card surface, `--hairline`
  row dividers, no team frames — **row recipe TBD (mockup first)**.
- *Menus / dropdowns / sheets*: `components/ui/neonMenu.ts` (40px rows, screen-height).

**7. Page chrome.** Bottom nav as in §8. Page header = **"H1 · Inline"** (Home, 2026-10-03): 52px
bar on `--bg-deep` with a `--hairline` bottom edge; "Pare" (20px/900) + gold-bright "NFL" label on
the left; controls on the right in a glass capsule (`--nav-bg` + `--glass-edge`, fully round,
36px buttons) with the active value in gold-bright. Its dropdown uses `neonMenu.ts` (gold header,
40px hairline rows, current row = gold edge). Section headers = **"D1 · Gold rule"**: gold-bright
10px/800 uppercase label tracked .2em, then a `--hairline` rule; a "WEEK n" divider is the same in
white 13px/900.

**8. Motion & effects.** Effects carry meaning (rank tier, Power Surge) — no decoration-only
animation. Opacity/transform only, ~30 fps canvases paused off-screen, everything has a
`prefers-reduced-motion` still state. Effects are opt-in props so dense screens stay calm.
**Effects play on change, then settle** — a short finite burst, then a still state; never an
infinite loop on a resting screen (small status signals like the live-game dot are the exception).
No full-screen `backdrop-filter` blur over content that animates (use a plain dim), and no blur
behind a surface that's nearly opaque anyway. Animated elements get `will-change` for the property
they animate; never animate `box-shadow`, `filter` or size on a glow — fade an extra layer instead.

**9. Layout & touch.** Mobile-first at 393px; iPad is an enhanced layout. Touch targets ≥ 44px
tall where possible. App shell: header + nav fixed, only content scrolls.

**10. Process.** New tab = (1) mockup rounds side by side, (2) Kobe picks, (3) write the picked
recipe into this section, (4) build with tokens, (5) gate + phone/iPad screenshots. Anything that
goes against these rules or standard practice gets flagged before building (CLAUDE.md).

### 9.1 Home game card — "Frame Row" (Home Round 2 pick, 2026-10-03)

Picked on the "Pare Home Redesign" mockup board: **A · Frame Row + H1 header + D1 day labels**, with
dials **G1 subtle glow · C2 standard color · N3 solid name · 24px**. Component:
`components/schedule/MatchupCard.tsx` (`MatchupCardSkeleton.tsx` matches its footprint).

| Part | Recipe |
|---|---|
| Frame | 1.5px, `line` color team A → `--frame-mid` → team B, radius `--radius-lg`; colors from `getMatchupPalettes()` (same lift + clash swap as Compare) |
| Glow (G1) | subtle side glow only: 14px blur at 25% per team. Compare's 34px / 34% is for one card — on a 16-card list it bleeds through the gaps |
| Surface | deep card gradient `--card-deep-a → mid → b`, 64px min row, 9×12px padding |
| Team | abbreviation **solid** in the team's `line` color, Inter 900, **24px** (every team ≥ 3:1 large-text contrast on `--card-deep-a`, unit-tested). Below: nickname 10px/600 `--subtext` + record `--muted` |
| Layout | grid `team 1fr · score 36px · center 64px · score 36px · team 1fr` — fixed, symmetric score slots |
| Center | pre: kickoff time 12px/700 white · network label · odds 9px `--muted` on two lines (spread / O/U) so it never overflows 64px · live: red pulsing dot (`.pare-live-dot`) + clock 11px/700 red · final: "FINAL" label + the same two-line odds |
| Scores | 20px/800, tabular, inboard of each team. Final: winner white, loser `--muted` (no arrow — too noisy) (same size/weight, ≈ 3.7:1 — still readable). Live and ties: both white (the lead can flip) |
| Open | gold-bright 1.5px ring + soft gold glow; the inline peek below is the Compare inline pane |
| Motion | tap scale 0.985; live-dot opacity pulse only; reduced motion → static dot |

Outlined abbreviations at 24px also passed the 20px rule (all 32 fit; widest, WAS, ≈ 59px in a
≥ 85px cell), but solid was picked for scan speed — it's what most sports apps use for team text.

